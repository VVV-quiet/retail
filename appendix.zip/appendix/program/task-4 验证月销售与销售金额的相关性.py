"""
    （饮料/非饮料）月销量与实际金额的散点图，验证月销量与预测销售金额的相关性
"""

import pandas as pd
import matplotlib,pylab as plt
import matplotlib.pylab as mpl  # 绘图中文乱码
mpl.rcParams['font.sans-serif'] = ['SimHei']
pd.set_option('display.max_columns', 1000)
pd.set_option('display.max_rows', 1000)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', 1000)

data = pd.read_csv(r"E:\Python\project\taidi\task1\merge_data_new.csv")
data_b = data.query('地点 == "B"')
data_new = data_b.groupby(['月份', '大类'])['实际金额'].sum().reset_index()
cnt_month = data.groupby(['月份', '大类'])['实际金额'].count().reset_index().rename(columns={'实际金额': '月销量'})
df = pd.merge(cnt_month, data_new, how='inner', on=['大类', '月份'])
drink = df.query('大类 == "饮料"')
no_drink = df.query('大类 == "非饮料 "')
plt.figure(1, figsize=(10, 12))
plt.subplot(211)
plt.scatter(x=drink['月销量'], y=drink['实际金额'])
plt.xlabel("月销量")
plt.ylabel("实际金额")
plt.title("饮料类月销量与实际金额的散点图")

plt.subplot(212)
plt.scatter(x=drink['月销量'], y=drink['实际金额'])
plt.xlabel("月销量")
plt.ylabel("实际金额")
plt.title("非饮料类月销量与实际金额的散点图")
plt.savefig(r'E:\Python\project\taidi\task2\predict.jpg')


plt.figure(2)
plt.scatter(x=df['月销量'], y=df['实际金额'])
plt.show()
print(df)
