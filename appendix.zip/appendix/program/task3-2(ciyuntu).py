"""
    任务3-2 词云图
    去除词频<0.01的商品
    词频是由售货机饮料类每个商品销量/各售货机商品总销量

"""
import matplotlib.pyplot as plt
import pandas as pd
from wordcloud import WordCloud, STOPWORDS

data = pd.read_csv(r"E:\Python\project\taidi\task1\merge_data_new.csv")
data = data.query('大类 == "饮料"')

data_a = data.query('地点 == "A"').copy()
data_b = data.query('地点 == "B"').copy()
data_c = data.query('地点 == "C"').copy()
data_d = data.query('地点 == "D"').copy()
data_e = data.query('地点 == "E"').copy()

cnt_a = round(data_a.groupby('商品')['商品'].count()/data_a.shape[0], 4)
cnt_a = cnt_a.sort_values(ascending=False)[0: 31]
cnt_b = round(data_b.groupby('商品')['商品'].count()/data_b.shape[0], 4)
cnt_b = cnt_b.sort_values(ascending=False)[0: 32]
cnt_c = round(data_c.groupby('商品')['商品'].count()/data_c.shape[0], 4)
cnt_c = cnt_c.sort_values(ascending=False)[0: 26]
cnt_d = round(data_d.groupby('商品')['商品'].count()/data_d.shape[0], 4)
cnt_d = cnt_d.sort_values(ascending=False)[0: 29]
cnt_e = round(data_e.groupby('商品')['商品'].count()/data_e.shape[0], 4)
cnt_e = cnt_e.sort_values(ascending=False)[0: 29]

wc = WordCloud(
    font_path='E:\Python\msyh.ttf',  # 设置字体，默认不支持中文
    background_color='skyblue',  # 背景颜色
    max_words=2000,  # 设置显示最大字数
    colormap='autumn',  # 设置字体颜色
)

wc_a = wc.fit_words(cnt_a)  # 根据词频生成词云
wc_a.to_file(r'E:\Python\project\taidi\task1\wordcloud_drink_AN.png')  # 图片保存
plt.figure(1)  # 图片显示
plt.imshow(wc_a)
plt.axis('off')  # 关闭坐标
plt.show()
wc_b = wc.fit_words(cnt_b)
plt.figure(2)
plt.imshow(wc_b)
plt.axis('off')
wc_b.to_file(r'E:\Python\project\taidi\task1\wordcloud_drink_BN.png')

wc_c = wc.fit_words(cnt_c)
wc_c.to_file(r'E:\Python\project\taidi\task1\wordcloud_drink_CN.png')
plt.figure(3)
plt.imshow(wc_c)
plt.axis('off')

wc_d = wc.fit_words(cnt_d)
wc_d.to_file(r'E:\Python\project\taidi\task1\wordcloud_drink_DN.png')
plt.figure(4)
plt.imshow(wc_d)
plt.axis('off')

wc_e = wc.fit_words(cnt_e)
wc_e.to_file(r'E:\Python\project\taidi\task1\wordcloud_drink_EN.png')
plt.figure(5)
plt.imshow(wc_e)
plt.axis('off')
plt.show()
