"""
    任务3.2
    增加消费档次标签：根据销售价格由高到低分为高档/中档/低档
    价格<25% 低档， 高于75%高档，其余中档，由于商品含多个价格，可能存在多个档次，故只保留一个
    应该是按单价来分档次，但是这里并不知道单价或者销售数量，故不考虑
"""
import pandas as pd
pd.set_option('display.max_columns', 1000)
pd.set_option('display.max_rows', 1000)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', 1000)
data_drink = pd.read_csv(r"E:\Python\project\taidi\task1\merge_data_new.csv")
a_label = pd.read_csv(r'E:\Python\project\taidi\task1\task3-1A.csv')
b_label = pd.read_csv(r'E:\Python\project\taidi\task1\task3-1B.csv')
c_label = pd.read_csv(r'E:\Python\project\taidi\task1\task3-1C.csv')
d_label = pd.read_csv(r'E:\Python\project\taidi\task1\task3-1D.csv')
e_label = pd.read_csv(r'E:\Python\project\taidi\task1\task3-1E.csv')

data_drink = data_drink.query('大类 == "饮料"')

# 1) A
data_drink_A = data_drink.query('地点 == "A"').copy()


def labels_a(a):
    if a <= 3:
        return "低档"
    elif a > 4.5:
        return "高档"
    else:
        return "正常"


data_drink_A['消费档次'] = data_drink_A.apply(lambda x: labels_a(x.应付金额), axis=1)
df_a = data_drink_A[['商品', '消费档次']].rename(columns={'商品': '饮料类商品'})
df_a.drop_duplicates(subset='饮料类商品', inplace=True)
df_a_new = pd.merge(a_label, df_a, how='inner', on='饮料类商品')
save_label_a = df_a_new.to_csv(r"task1\task3-2A.csv", sep=',', encoding='utf_8_sig', index=False)

# 2）B
data_drink_B = data_drink.query('地点 == "B"').copy()


def labels_b(a):
    if a <= 3:
        return "低档"
    elif a > 4.5:
        return "高档"
    else:
        return "正常"


data_drink_B['消费档次'] = data_drink_B.apply(lambda x: labels_a(x.应付金额), axis=1)
df_b = data_drink_B[['商品', '消费档次']].rename(columns={'商品': '饮料类商品'})
df_b.drop_duplicates(subset='饮料类商品', inplace=True)
df_b_new = pd.merge(b_label, df_b, how='inner', on='饮料类商品')
save_label_b = df_b_new.to_csv(r"task1\task3-2B.csv", sep=',', encoding='utf_8_sig', index=False)


# 3) C
data_drink_C = data_drink.query('地点 == "C"').copy()


def labels_c(a):
    if a <= 3:
        return "低档"
    elif a > 4.5:
        return "高档"
    else:
        return "正常"


data_drink_C['消费档次'] = data_drink_C.apply(lambda x: labels_c(x.应付金额), axis=1)
df_c = data_drink_C[['商品', '消费档次']].rename(columns={'商品': '饮料类商品'})
df_c.drop_duplicates(subset='饮料类商品', inplace=True)
df_c_new = pd.merge(c_label, df_c, how='inner', on='饮料类商品')
save_label_c = df_c_new.to_csv(r"task1\task3-2C.csv", sep=',', encoding='utf_8_sig', index=False)


# 4） D
data_drink_D = data_drink.query('地点 == "D"').copy()


def labels_d(a):
    if a <= 3:
        return "低档"
    elif a > 4.5:
        return "高档"
    else:
        return "正常"


data_drink_D['消费档次'] = data_drink_D.apply(lambda x: labels_c(x.应付金额), axis=1)
df_d = data_drink_D[['商品', '消费档次']].rename(columns={'商品': '饮料类商品'})
df_d.drop_duplicates(subset='饮料类商品', inplace=True)
df_d_new = pd.merge(d_label, df_d, how='inner', on='饮料类商品')
save_label_d = df_c_new.to_csv(r"task1\task3-2D.csv", sep=',', encoding='utf_8_sig', index=False)


# 5 E
data_drink_E = data_drink.query('地点 == "E"').copy()


def labels_e(a):
    if a <= 3:
        return "低档"
    elif a > 4.5:
        return "高档"
    else:
        return "正常"


data_drink_E['消费档次'] = data_drink_E.apply(lambda x: labels_c(x.应付金额), axis=1)
df_e = data_drink_E[['商品', '消费档次']].rename(columns={'商品': '饮料类商品'})
df_e.drop_duplicates(subset='饮料类商品', inplace=True)
df_e_new = pd.merge(e_label, df_e, how='inner', on='饮料类商品')
print(df_e_new)
save_label_e = df_e_new.to_csv(r"task1\task3-2E.csv", sep=',', encoding='utf_8_sig', index=False)
