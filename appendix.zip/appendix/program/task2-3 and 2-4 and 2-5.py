"""
    任务三：数据分析与可视化
    任务2.3、任务2.4、任务2.5
"""
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
pd.set_option('display.max_columns', 1000)
pd.set_option('display.max_rows', 1000)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', 1000)
matplotlib.rcParams['font.sans-serif'] = ['SimHei']   # 用黑体显示中文
matplotlib.rcParams['axes.unicode_minus'] = False  # 正常显示负号

data = pd.read_csv(r"E:\Python\project\taidi\task1\merge_data.csv")
data = data.copy()
data['月份'] = data['支付时间'].str[5: 7]
data['天'] = data['支付时间'].str[8: 10]
data['小时'] = data['支付时间'].str[11: 13]
data["支付时间"] = pd.to_datetime(data["支付时间"])
# data_new = data.to_csv(r"E:\Python\project\taidi\task1\merge_data_new.csv", sep=',',
# encoding='utf_8_sig', index=False)
a = data.query('地点=="A"')
b = data.query('地点=="B"')
c = data.query('地点=="C"')
d = data.query('地点=="D"')
e = data.query('地点=="E"')

# 任务2.3 每台售货机毛利润占总毛利润比例 饼图
maoli_a = a.query('大类 == "饮料"')["实际金额"].sum()*0.25 + a.query('大类 == "非饮料"')["实际金额"].sum()*0.20
maoli_b = b.query('大类 == "饮料"')["实际金额"].sum()*0.25 + b.query('大类 == "非饮料"')["实际金额"].sum()*0.20
maoli_c = c.query('大类 == "饮料"')["实际金额"].sum()*0.25 + c.query('大类 == "非饮料"')["实际金额"].sum()*0.20
maoli_d = d.query('大类 == "饮料"')["实际金额"].sum()*0.25 + d.query('大类 == "非饮料"')["实际金额"].sum()*0.20
maoli_e = e.query('大类 == "饮料"')["实际金额"].sum()*0.25 + e.query('大类 == "非饮料"')["实际金额"].sum()*0.20
maoli_total = data.query('大类 == "饮料"')["实际金额"].sum()*0.25 + data.query('大类 == "非饮料"')["实际金额"].sum()*0.20

proportion_a = maoli_a/maoli_total
proportion_b = maoli_b/maoli_total
proportion_c = maoli_c/maoli_total
proportion_d = maoli_d/maoli_total
proportion_e = maoli_e/maoli_total
pro_lst = [proportion_a, proportion_b, proportion_c, proportion_d, proportion_e]
plt.figure(1)
plt.pie(pro_lst, labels=['A', 'B', 'C', 'D', 'E'], autopct='%.1f%%')
plt.savefig(r'E:\Python\project\taidi\task2\task2_4.jpg')
plt.title("每台售货机毛利润占总毛利润比例")

# 任务2.4 每月交易额均值气泡图,横轴为时间，纵轴为商品二级分类
# 每月交易额均值较小，气泡图不明显，所以将值扩大了15倍
mean = round(data.groupby(['二级类', '月份'])['实际金额'].mean(), 2).reset_index()  # 每月交易额均值
mean = mean.rename(columns={'实际金额': '每月交易额均值'})
# to_mean = mean.to_csv(r"task1\每月交易额均值.csv", sep=',', encoding='utf_8_sig', index=False)
colors = {'01': 'skyblue', '02': 'red', '03': 'orange', '04': 'brown', '05': 'purple', '06': 'pink', '07': 'green',
          '08': 'gray', '09': 'red', '10': 'skyblue', '11': 'brown', '12': 'orange'}
plt.figure(2)
plt.scatter(x=mean['月份'], y=mean['二级类'], s=mean['每月交易额均值']*15, c=[colors[i] for i in mean['月份']])
plt.xlabel("时间")
plt.ylabel("商品二级分类")
plt.title("每月交易额均值气泡图")
plt.savefig(r'E:\Python\project\taidi\task2\task2_5.jpg')


# 绘制C 6/7/8三个月订单量的热力图，横轴单位：天，纵轴单位：小时
cnt_c06 = c.query('月份 == "06"').groupby(['天', '小时'])['小时'].count()  # 每天每小时的订单量
"""6月份订单量的热力图"""
cnt_c06.index.names = ['天', '小时']
cnt_c06 = cnt_c06.unstack(level=0).fillna(0)  # 转为矩阵，并将NaN填充为0
plt.figure(3)
sns.heatmap(cnt_c06, cmap='YlGnBu')
plt.title('6月份订单量热力图')
plt.savefig(r'E:\Python\project\taidi\task2\task2_6.jpg')

cnt_c07 = c.query('月份 == "07"').groupby(['天', '小时'])['小时'].count()
"""7月订单量热力图"""
cnt_c07.index.names = ['天', '小时']
cnt_c07 = cnt_c07.unstack(level=0).fillna(0)
plt.figure(4)
sns.heatmap(cnt_c07, cmap='YlGnBu')
plt.title('7月份订单量热力图')
plt.savefig(r'E:\Python\project\taidi\task2\task2_7.jpg')

cnt_c08 = c.query('月份 == "08"').groupby(['天', '小时'])['小时'].count()
"""8月份订单量的热力图"""
cnt_c08.index.names = ['天', '小时']
cnt_c08 = cnt_c08.unstack(level=0).fillna(0)
plt.figure(5)
sns.heatmap(cnt_c08, cmap='YlGnBu')
plt.title('8月份订单量热力图')
plt.savefig(r'E:\Python\project\taidi\task2\task2_8.jpg')
c = c.set_index('支付时间')
plt.show()
# print(cnt_c06)



