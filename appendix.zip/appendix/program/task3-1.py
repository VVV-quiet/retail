"""
   任务3.1：标签划分
   滞销：小于销量后25%且商品没有月转
   热销：销量在前5%，且有连续月转，商品按销量降序可查看前5%的阈值范围
   销量75%的数值都较小，不可取热销的阈值
"""
import pandas as pd
pd.set_option('display.max_columns', 1000)
pd.set_option('display.max_rows', 1000)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', 1000)
data_drink = pd.read_csv(r"E:\Python\project\taidi\task1\merge_data_new.csv")
data_drink = data_drink.copy()
data_drink = data_drink.query('大类 == "饮料"')

# 1) A售货机标签：50%--19, 25%--6, 70%--68, min--1, max--531
data_drink_A = data_drink.query('地点 == "A"').copy()
cnt_a = data_drink_A.groupby('商品')['商品'].count()  # 商品销量
drink_a_months_cnt = data_drink_A.groupby('商品')['月份'].unique().apply(len)  # 计算一件商品共出现几个月
df_a = pd.DataFrame({'饮料类商品': cnt_a.index, '商品销量': cnt_a, '月份个数': drink_a_months_cnt}).reset_index()


def labels_a(a, b):
    if a >= 200 and b == 12:
        return "热销"  # 6个
    elif a < 6 and b <= 1:
        return "滞销"  # 7个
    else:
        return "正常"  # 99个


df_a['标签'] = df_a.apply(lambda x: labels_a(x.商品销量, x.月份个数), axis=1)
df_a = df_a[['饮料类商品', '标签']]
# save_label_a = df_a.to_csv(r"task1\test_A.csv", sep=',', encoding='utf_8_sig', index=False)


# 2) B售货机标签：min--1, 25%--5, 50%--17, 75%--95, max--1342
data_drink_B = data_drink.query('地点 == "B"').copy()
cnt_b = data_drink_B.groupby('商品')['商品'].count()  # b商品销量
drink_b_months_cnt = data_drink_B.groupby('商品')['月份'].unique().apply(len)  # 计算一件商品共出现几个月
df_b = pd.DataFrame({'饮料类商品': cnt_b.index, '商品销量': cnt_b, '月份个数': drink_b_months_cnt}).reset_index()


def labels_b(a, b):
    if a >= 300 and 10 <= b <= 12:
        return "热销"  # 7个
    elif a < 5 and b <= 1:
        return "滞销"  # 11个
    else:
        return "正常"  # 97个


df_b['标签'] = df_b.apply(lambda x: labels_b(x.商品销量, x.月份个数), axis=1)
df_b = df_b[['饮料类商品', '标签']]
# save_label_b = df_b.to_csv(r"task1\task3-1B.csv", sep=',', encoding='utf_8_sig', index=False)


# 3) C售货机标签：min--1, 25%--6, 50%--24, 75%--80, max--999
data_drink_C = data_drink.query('地点 == "C"').copy()
cnt_c = data_drink_C.groupby('商品')['商品'].count()  # c商品销量
drink_c_months_cnt = data_drink_C.groupby('商品')['月份'].unique().apply(len)  # 计算一件商品共出现几个月
df_c = pd.DataFrame({'饮料类商品': cnt_c.index, '商品销量': cnt_c, '月份个数': drink_c_months_cnt}).reset_index()


def labels_c(a, b):
    if a >= 400 and 10 <= b <= 12:
        return "热销"  # 6个
    elif a < 6 and b <= 1:
        return "滞销"  # 5个
    else:
        return "正常"  # 103个


df_c['标签'] = df_c.apply(lambda x: labels_c(x.商品销量, x.月份个数), axis=1)
df_c = df_c[['饮料类商品', '标签']]
# save_label_c = df_c.to_csv(r"task1\task3-1C.csv", sep=',', encoding='utf_8_sig', index=False)


# 4) D售货机标签：min--1, 25%--3, 50%--15, 75%--64, max--411
data_drink_D = data_drink.query('地点 == "D"').copy()
cnt_d = data_drink_D.groupby('商品')['商品'].count()  # d商品销量
drink_d_months_cnt = data_drink_D.groupby('商品')['月份'].unique().apply(len)  # 计算一件商品共出现几个月
df_d = pd.DataFrame({'饮料类商品': cnt_d.index, '商品销量': cnt_d, '月份个数': drink_d_months_cnt}).reset_index()


def labels_d(a, b):
    if a >= 280 and 10 <= b <= 12:
        return "热销"  # 6个
    elif a < 3 and b <= 1:
        return "滞销"  # 13个
    else:
        return "正常"  # 86个


df_d['标签'] = df_d.apply(lambda x: labels_d(x.商品销量, x.月份个数), axis=1)
df_d = df_d[['饮料类商品', '标签']]
# save_label_d = df_d.to_csv(r"task1\task3-1D.csv", sep=',', encoding='utf_8_sig', index=False)


# 5) E售货机标签：min--1, 25%--11, 50%--47, 75%--169, max--1705
data_drink_E = data_drink.query('地点 == "E"').copy()
cnt_e = data_drink_E.groupby('商品')['商品'].count()  # e商品销量
drink_e_months_cnt = data_drink_E.groupby('商品')['月份'].unique().apply(len)  # 计算一件商品共出现几个月
df_e = pd.DataFrame({'饮料类商品': cnt_e.index, '商品销量': cnt_e, '月份个数': drink_e_months_cnt}).reset_index()


def labels_e(a, b):
    if a >= 600 and 10 <= b <= 12:
        return "热销"  # 6个
    elif a < 11 and b <= 1:
        return "滞销"  # 5个
    else:
        return "正常"  # 102个


df_e['标签'] = df_e.apply(lambda x: labels_e(x.商品销量, x.月份个数), axis=1)
df_e = df_e[['饮料类商品', '标签']]
# save_label_e = df_e.to_csv(r"task1\task3-1E.csv", sep=',', encoding='utf_8_sig', index=False)

