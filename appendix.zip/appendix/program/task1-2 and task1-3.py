"""
    任务一：数据预处理与分析
    任务1.2
    任务1.3
"""
import pandas as pd
pd.set_option('display.max_columns', 1000)
pd.set_option('display.max_rows', 1000)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', 1000)

data_A = pd.read_csv(r"task1\task1-1A.csv")
data_A["支付时间"] = pd.to_datetime(data_A["支付时间"])
data_A = data_A.set_index("支付时间")
data_B = pd.read_csv(r"task1\task1-1B.csv")
data_B["支付时间"] = pd.to_datetime(data_B["支付时间"])
data_B = data_B.set_index("支付时间")  # 将时间设置为行索引
data_C = pd.read_csv(r"task1\task1-1C.csv")
data_C["支付时间"] = pd.to_datetime(data_C["支付时间"])
data_C = data_C.set_index("支付时间")
data_D = pd.read_csv(r"task1\task1-1D.csv")
data_D["支付时间"] = pd.to_datetime(data_D["支付时间"])
data_D = data_D.set_index("支付时间")
data_E = pd.read_csv(r"task1\task1-1E.csv")
data_E["支付时间"] = pd.to_datetime(data_E["支付时间"])
data_E = data_E.set_index("支付时间")
# sort_rmb = data_B.groupby('商品')['实际金额'].value_counts()  # 观察每个商品的金额
# quchong = sum(data_B.duplicated(subset="订单号"))

# 任务1.2：每台售货机5月份交易额和订单量、所有售货机交易总额和订单总量
amount_A_05 = data_A['2017-05']
amount_B_05 = data_B['2017-05']
amount_C_05 = data_C['2017-05']
amount_D_05 = data_D['2017-05']
amount_E_05 = data_E['2017-05']
amt_total = len(data_A)+len(data_B)+len(data_C)+len(data_D)+len(data_E)
sum_a, cnt_a = sum(amount_A_05["实际金额"]), amount_A_05.count()[0]
sum_b, cnt_b = sum(amount_B_05["实际金额"]), amount_B_05.count()[0]
sum_c, cnt_c = sum(amount_C_05["实际金额"]), amount_C_05.count()[0]
sum_d, cnt_d = sum(amount_D_05["实际金额"]), amount_D_05.count()[0]
sum_e, cnt_e = sum(amount_E_05["实际金额"]), amount_E_05.count()[0]
sum_total = sum(data_A["实际金额"])+sum(data_B["实际金额"])+sum(data_C["实际金额"])+sum(data_D["实际金额"])+sum(data_E["实际金额"])
print("A售货机5月份交易额:{:.2f}".format(sum_a), '\n'"A售货机5月份交易量:", cnt_a)
print("B售货机5月份交易额:{:.2f}".format(sum_b), '\n'"B售货机5月份交易量:", cnt_b)
print("C售货机5月份交易额:{:.2f}".format(sum_c), '\n'"C售货机5月份交易量:", cnt_c)
print("D售货机5月份交易额:{:.2f}".format(sum_d), '\n'"D售货机5月份交易量:", cnt_d)
print("E售货机5月份交易额:{:.2f}".format(sum_e), '\n'"E售货机5月份交易量:", cnt_e)
print("所有售货机5月份交易额:{:.2f}".format(sum_a+sum_b+sum_c+sum_d+sum_e), '\n'"所有售货机5月份交易量:", cnt_a+cnt_b+cnt_c+cnt_d+cnt_e)
print("所有售货机订单总量:{:.2f}".format(sum_total), '\n'"所有售货机订单总量:", amt_total)

# 任务1.3：计算每台售货机每月的每单平均交易额与日均订单量
amt_grouped_a = data_A.groupby(lambda x: x.month)['实际金额'].mean()  # 每月每单平均交易额
cnt_grouped_a = data_A.groupby(lambda x: x.day)["实际金额"].count()  # 订单量
cnt_mon_avg_a = round(data_A.groupby(lambda x: x.month)['实际金额'].count()/31)  # 每月日均订单量
cnt_mean_a = data_A.count()[0]/365.  # 日均订单量

amt_grouped_b = data_B.groupby(lambda x: x.month)['实际金额'].mean()
cnt_grouped_b = data_B.groupby(lambda x: x.day)["实际金额"].count()
cnt_mon_avg_b = round(data_B.groupby(lambda x: x.month)['实际金额'].count()/31)
cnt_mean_b = data_B.count()[0]/365.

amt_grouped_c = data_C.groupby(lambda x: x.month)['实际金额'].mean()
cnt_grouped_c = data_C.groupby(lambda x: x.day)["实际金额"].count()
cnt_mon_avg_c = round(data_C.groupby(lambda x: x.month)['实际金额'].count()/31)
cnt_mean_c = data_C.count()[0]/365.

amt_grouped_d = data_D.groupby(lambda x: x.month)['实际金额'].mean()
cnt_grouped_d = data_D.groupby(lambda x: x.day)["实际金额"].count()
cnt_mon_avg_d = round(data_D.groupby(lambda x: x.month)['实际金额'].count()/31)
cnt_mean_d = data_D.count()[0]/365.

amt_grouped_e = data_E.groupby(lambda x: x.month)['实际金额'].mean()
cnt_grouped_e = data_E.groupby(lambda x: x.day)["实际金额"].count()
cnt_mon_avg_e = round(data_E.groupby(lambda x: x.month)['实际金额'].count()/31)
cnt_mean_e = data_E.count()[0]/365.

print("A每月每单平均交易额:\n", amt_grouped_a, '\n'"A每月日均订单量：\n", cnt_mon_avg_a, '\n'"A日均订单量:\n", round(cnt_mean_a))
print("B每月每单平均交易额:\n", amt_grouped_b, '\n'"B每月日均订单量：\n", cnt_mon_avg_b, '\n'"B日均订单量:\n", round(cnt_mean_b))
print("C每月每单平均交易额:\n", amt_grouped_c, '\n'"C每月日均订单量：\n", cnt_mon_avg_c, '\n'"C日均订单量:\n", round(cnt_mean_c))
print("D每月每单平均交易额:\n", amt_grouped_d, '\n'"D每月日均订单量：\n", cnt_mon_avg_d, '\n'"D日均订单量:\n", round(cnt_mean_d))
print("E每月每单平均交易额:\n", amt_grouped_e, '\n'"E每月日均订单量：\n", cnt_mon_avg_e, '\n'"E日均订单量:\n", round(cnt_mean_e))

