"""
    任务二：数据分析与可视化
    任务2.1、任务2.2
"""
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import numpy as np

data = pd.read_csv(r"E:\Python\project\taidi\project_data_taidi\附件1.csv", encoding='gbk', sep=',')
data = data.copy()
data.drop(70679, axis=0, inplace=True)  # 删除日期错误的行
data["支付时间"] = pd.to_datetime(data["支付时间"])
data = data.set_index('支付时间')

# 2.1 绘制2017年6月销售前5的商品销量柱状图
matplotlib.rcParams['font.sans-serif'] = ['SimHei']   # 用黑体显示中文
matplotlib.rcParams['axes.unicode_minus'] = False  # 正常显示负号
data_06 = data['2017-06']
grouped = data_06.groupby('商品').count()['订单号']
grouped_head5 = grouped.sort_values(ascending=False).head()
plt.figure(1)
grouped_head5.plot(kind='bar')
plt.title("2017年6月销售前5的商品销量柱状图")
plt.xlabel('商品名称')
plt.ylabel('商品销量(单位：件)')
plt.xticks(rotation=0)
plt.savefig(r'E:\Python\project\taidi\task2\task2_1.jpg')
# plt.show()
# print(grouped_head5)

# 2.2 绘制每台售货机每月交易额折线图及交易额月环比增长率柱状图
# 1）每台售货机每月交易额折线图
grouped_A = data.query('地点=="A"').groupby(lambda x: x.month)['实际金额'].sum()
grouped_B = data.query('地点=="B"').groupby(lambda x: x.month)['实际金额'].sum()
grouped_C = data.query('地点=="C"').groupby(lambda x: x.month)['实际金额'].sum()
grouped_D = data.query('地点=="D"').groupby(lambda x: x.month)['实际金额'].sum()
grouped_E = data.query('地点=="E"').groupby(lambda x: x.month)['实际金额'].sum()
plt.figure(2)
plt.plot(grouped_A, 'b*-', grouped_B, 'r*-', grouped_C, 'g*-', grouped_D, 'y*-', grouped_E, 'c*-')
plt.xticks([i for i in range(1, 13)])
plt.title("每台售货机每月总交易额折线图")
plt.xlabel("月份")
plt.ylabel("每月总销售额(单位：元)")
plt.legend(["A售货机", "B售货机", "C售货机", "D售货机", "E售货机"], loc='best')
plt.savefig(r'E:\Python\project\taidi\task2\task2_2.jpg')

# 2）交易额月环比增长率柱状图
plt.figure(3)
huanbi_A = grouped_A.pct_change()
huanbi_A.fillna(0, inplace=True)
huanbi_B = grouped_B.pct_change()
huanbi_B.fillna(0, inplace=True)
huanbi_C = grouped_C.pct_change()
huanbi_C.fillna(0, inplace=True)
huanbi_D = grouped_D.pct_change()
huanbi_D.fillna(0, inplace=True)
huanbi_E = grouped_E.pct_change()
huanbi_E.fillna(0, inplace=True)
ind = np.arange(len(huanbi_A))
# total_width, n = 0.7, 5  # n是绘制柱状图的个数5
width = 0.15  # 条柱宽度 total_width/n
# x = x-(total_width-width)/2  # 缩短条柱到原点的距离，从1缩近到0.几
plt.bar(ind, huanbi_A, width, color='r', label='A')
plt.bar(ind+width, huanbi_B, width, color='y')
plt.bar(ind+width*2, huanbi_C, width, color='B')
plt.bar(ind+width*3, huanbi_D, width, color='g')
plt.bar(ind+width*4, huanbi_E, width, color='m')
plt.xticks(ind+width*2, labels=[i for i in range(1, 13)])  # x轴刻度位置与标签
plt.title("交易额月环比增长率柱状图")
plt.xlabel("月份")
plt.ylabel("交易额月环比增长率")
plt.grid(linestyle=':')
plt.legend(['A', 'B', 'C', 'D', 'E'])
plt.savefig(r'E:\Python\project\taidi\task2\task2_3.jpg')
# print("B:\n", huanbi_A)
plt.show()


