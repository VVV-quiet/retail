"""
    内容：任务一：数据预处理与分析
    任务1.1 分别提取每台售货机销售数据
    合并附件一和附件二数据，便于后续任务使用
"""
import pandas as pd
pd.set_option('displaymax_columns', 1000)
pd.set_option('display.max_rows', 1000)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', 1000)

data = pd.read_csv(r"E:\Python\project\taidi\project_data_taidi\附件1.csv", encoding='gbk', sep=',')
data = data.copy()
data.drop(70679, axis=0, inplace=True)  # 删除日期错误的行
data["支付时间"] = pd.to_datetime(data["支付时间"])  # 修正时间类型
data = data.set_index("支付时间")

# 销售和分类数据合并，便于后续任务使用
data_category = pd.read_csv(r"E:\Python\project\taidi\project_data_taidi\附件2.csv", encoding='gbk', sep=',')
data_merge = pd.merge(left=data_category, right=data, how='inner', on='商品')
data_merge = data_merge.set_index("支付时间")
save_data = data.to_csv(r"task1\merge_data.csv", sep=',', encoding='utf_8_sig', index=False)

# 任务1.1：分别提取每台售货机对应的销售数据
data_A = data.query("地点=='A'")
data_B = data.query("地点=='B'")
data_C = data.query("地点=='C'")
data_D = data.query("地点=='D'")
data_E = data.query("地点=='E'")
to_data_A = data_A.to_csv(r"task1\task1-1A.csv", sep=',', encoding='utf_8_sig', index=False)
to_data_B = data_B.to_csv(r"task1\task1-1B.csv", sep=',', encoding='utf_8_sig', index=False)
to_data_C = data_C.to_csv(r"task1\task1-1C.csv", sep=',', encoding='utf_8_sig', index=False)
to_data_D = data_D.to_csv(r"task1\task1-1D.csv", sep=',', encoding='utf_8_sig', index=False)
to_data_E = data_E.to_csv(r"task1\task1-1E.csv", sep=',', encoding='utf_8_sig', index=False)
